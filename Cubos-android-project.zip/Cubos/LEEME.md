# Cubos – proyecto Android (WebView)

La app envuelve el juego (app/src/main/assets/index.html) a pantalla completa y en horizontal.
El juego ya incluye three.js DENTRO del HTML: funciona 100% sin internet y no hay que descargar nada al compilar.
Los mundos y ajustes se guardan en el propio teléfono.

## Opción A: Android Studio
1. Abre esta carpeta (File > Open) y espera a que sincronice.
2. Build > Build Bundle(s) / APK(s) > Build APK(s).
3. El archivo queda en app/build/outputs/apk/debug/app-debug.apk. Cópialo al teléfono e instálalo.

## Opción B: sin instalar nada (GitHub)
1. Sube el zip a un repositorio de GitHub y crea .github/workflows/build.yml con el contenido de ese archivo del zip.
2. Pestaña Actions > "Build APK" > Run workflow. Descarga "cubos-apk" cuando termine.

Nota: es un APK de depuración (uso personal). Si ya tenías Cubos instalado y no deja actualizar, desinstálalo primero (se pierden los mundos guardados).
